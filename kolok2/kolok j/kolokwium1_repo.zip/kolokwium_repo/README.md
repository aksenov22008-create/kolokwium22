# Kolokwium Java OOP - Repo startowe

Repozytorium przygotowane na podstawie analizy kolokwiów z lat **2021–2024**.

## ⚡ Szybki start (pierwsze 15 minut)

```bash
# 1. Sklonuj lub rozpakuj repo
# 2. Otwórz w IntelliJ IDEA (File → Open → wybierz pom.xml)
# 3. Poczekaj aż Maven pobierze zależności
# 4. Przeczytaj CHEATSHEET.md i zacznij od kroku 1
```

## 📁 Pliki

| Plik | Opis |
|------|------|
| `CHEATSHEET.md` | **Główna ściągawka** - wzorce z komentarzami |
| `src/main/java/AbstractBase.java` | Szablon klasy abstrakcyjnej + fromCsv |
| `src/main/java/CsvParser.java` | Snippety do parsowania CSV |
| `src/main/java/ExceptionTemplates.java` | Wzorce własnych wyjątków |
| `src/main/java/SortingExamples.java` | Sortowanie i komparatory |
| `src/main/java/FileIOExamples.java` | Zapis/odczyt plików |
| `src/main/java/FunctionalExamples.java` | Interfejsy funkcyjne, Streams |
| `src/main/java/GeometrySvgExamples.java` | Geometria (2023) + SVG (2024) |
| `src/main/java/TimeExamples.java` | LocalTime, strefy, format 12h/24h (2024) |
| `src/test/java/ExampleTest.java` | Szablony testów JUnit 5 |

## 🔑 Zależności (pom.xml)

- **JUnit 5** `5.10.2` - testy
- **Jackson XML** `2.17.1` - parsowanie SVG (2023)
- Java **21**

## 📋 Wzorzec każdego kolokwium

```
Krok 1-2:  Klasa abstrakcyjna + podklasy
Krok 2-3:  fromCsv + własny wyjątek  
Krok 4-5:  Struktury danych + uzupełnienie fromCsv
Krok 6:    Przeciążenie metody
Krok 7-8:  Metody abstrakcyjne + sortowanie
Krok 9+:   Zapis do pliku / Jackson / JUnit
```
