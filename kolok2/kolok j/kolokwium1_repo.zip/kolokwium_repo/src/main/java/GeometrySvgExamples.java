// ============================================================
// SNIPPETY: Geometria (2023) + SVG (2024)
// ============================================================

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class GeometrySvgExamples {

    // -------------------------------------------------------
    // 1. Point jako record (krok 1, 2023)
    // -------------------------------------------------------
    record Point(double x, double y) {
        double distanceTo(Point other) {
            double dx = this.x - other.x;
            double dy = this.y - other.y;
            return Math.sqrt(dx * dx + dy * dy);
        }
    }

    // -------------------------------------------------------
    // 2. Algorytm "punkt w wielokącie" - ray casting
    //    Wzorzec: Polygon.inside() (2023, krok 3)
    // -------------------------------------------------------
    static boolean insidePolygon(List<Point> polygon, Point point) {
        int counter = 0;
        int n = polygon.size();
        for (int i = 0; i < n; i++) {
            Point pa = polygon.get(i);
            Point pb = polygon.get((i + 1) % n);

            if (pa.y() > pb.y()) {
                Point tmp = pa; pa = pb; pb = tmp;
            }
            if (pa.y() < point.y() && point.y() < pb.y()) {
                double d = pb.x() - pa.x();
                double x;
                if (d == 0) {
                    x = pa.x();
                } else {
                    double a = (pb.y() - pa.y()) / d;
                    double b = pa.y() - a * pa.x();
                    x = (point.y() - b) / a;
                }
                if (x < point.x()) counter++;
            }
        }
        return counter % 2 == 1;
    }

    // -------------------------------------------------------
    // 3. Kwadrat z centrum i długością boku (City, 2023 krok 6)
    //    Zwraca 4 wierzchołki kwadratu
    // -------------------------------------------------------
    static List<Point> squareVertices(Point center, double sideLength) {
        double half = sideLength / 2.0;
        return List.of(
            new Point(center.x() - half, center.y() - half),
            new Point(center.x() + half, center.y() - half),
            new Point(center.x() + half, center.y() + half),
            new Point(center.x() - half, center.y() + half)
        );
    }

    // -------------------------------------------------------
    // 4. Generowanie SVG - tarcza zegara analogowego (2024 krok 7)
    // -------------------------------------------------------
    static String clockFaceSvg(int cx, int cy, int radius) {
        StringBuilder sb = new StringBuilder();
        sb.append("""
            <svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">
            """.formatted(cx * 2, cy * 2));
        // Tarcza
        sb.append("<circle cx=\"%d\" cy=\"%d\" r=\"%d\" fill=\"white\" stroke=\"black\" stroke-width=\"3\"/>%n"
                .formatted(cx, cy, radius));
        // Cyfry godzinowe
        for (int h = 1; h <= 12; h++) {
            double angle = Math.toRadians(h * 30 - 90);
            int tx = (int)(cx + (radius - 20) * Math.cos(angle));
            int ty = (int)(cy + (radius - 20) * Math.sin(angle));
            sb.append("<text x=\"%d\" y=\"%d\" text-anchor=\"middle\" dominant-baseline=\"middle\">%d</text>%n"
                    .formatted(tx, ty, h));
        }
        sb.append("</svg>");
        return sb.toString();
    }

    // -------------------------------------------------------
    // 5. Wskazówka jako linia SVG obrócona o kąt
    //    Wzorzec: ClockHand.toSvg (2024, kroki 9-10)
    //    angle = stopnie, zgodnie z ruchem wskazówek
    // -------------------------------------------------------
    static String handSvg(int cx, int cy, int length, double angleDeg,
                           int strokeWidth, String color) {
        return "<line x1=\"%d\" y1=\"%d\" x2=\"%d\" y2=\"%d\" "
             + "stroke=\"%s\" stroke-width=\"%d\" "
             + "transform=\"rotate(%.2f %d %d)\"/>"
             .formatted(cx, cy, cx, cy - length,
                        color, strokeWidth,
                        angleDeg, cx, cy);
    }

    // Kąt wskazówki sekundowej (dyskretny, 2024 krok 9)
    static double secondAngle(int second) {
        return second * 6.0; // 360/60 = 6 stopni na sekundę
    }

    // Kąt wskazówki minutowej (ciągły, 2024 krok 10)
    static double minuteAngle(int minute, int second) {
        return minute * 6.0 + second * 0.1;
    }

    // Kąt wskazówki godzinowej (ciągły, 2024 krok 10)
    static double hourAngle(int hour, int minute, int second) {
        return (hour % 12) * 30.0 + minute * 0.5 + second / 120.0;
    }

    // -------------------------------------------------------
    // 6. Parsowanie SVG z Jacksonem (MapParser, 2023 krok 13)
    //    Wzorzec importu: dodaj do pom.xml
    //    groupId: com.fasterxml.jackson.dataformat
    //    artifactId: jackson-dataformat-xml
    // -------------------------------------------------------
    // Patrz plik MapParser.java (dołączony do kolokwium 2023)
    // Kluczowe adnotacje:
    //   @JacksonXmlElementWrapper(useWrapping = false)
    //   @JsonProperty("polygon")
    //   private List<Map<String, String>> polygons;
    //
    // Parsowanie "points" z SVG polygon:
    static List<Point> parseSvgPoints(String pointsAttr) {
        // Format: "x1,y1 x2,y2 x3,y3"
        List<Point> pts = new ArrayList<>();
        for (String pair : pointsAttr.trim().split("\\s+")) {
            String[] xy = pair.split(",");
            pts.add(new Point(Double.parseDouble(xy[0]), Double.parseDouble(xy[1])));
        }
        return pts;
    }

    // Parsowanie rect (x, y, width, height) → centrum
    static Point rectCenter(double x, double y, double width, double height) {
        return new Point(x + width / 2, y + height / 2);
    }
}
