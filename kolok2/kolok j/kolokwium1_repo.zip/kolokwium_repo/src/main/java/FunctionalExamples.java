// ============================================================
// SNIPPETY: Interfejsy funkcyjne i Streams
// Wzorzec: kolokwium 2022 (addProducts z Function)
// ============================================================

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.function.*;
import java.util.stream.*;

public class FunctionalExamples {

    // -------------------------------------------------------
    // 1. Interfejs funkcyjny do metod wytwórczych (fromCsv)
    //    Wzorzec: addProducts (2022, krok 3)
    //    Typ: Function<Path, T> lub własny @FunctionalInterface
    // -------------------------------------------------------
    @FunctionalInterface
    interface CsvFactory<T> {
        T create(Path path) throws IOException;
    }

    // Użycie:
    //   addProducts(NonFoodProduct::fromCsv, Path.of("data/nonfood"));
    //   addProducts(FoodProduct::fromCsv,    Path.of("data/food"));

    static <T> List<T> loadFromDirectory(CsvFactory<T> factory, Path dir) throws IOException {
        var result = new ArrayList<T>();
        try (var stream = Files.list(dir)) {
            for (Path p : stream.filter(f -> f.toString().endsWith(".csv"))
                               .collect(Collectors.toList())) {
                try {
                    result.add(factory.create(p));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return result;
    }

    // -------------------------------------------------------
    // 2. Streams - najczęściej używane operacje
    // -------------------------------------------------------
    record Product(String name, double price) {}

    static void streamExamples(List<Product> products) {
        // filter + collect
        List<Product> cheap = products.stream()
            .filter(p -> p.price() < 10)
            .collect(Collectors.toList());

        // map
        List<String> names = products.stream()
            .map(Product::name)
            .collect(Collectors.toList());

        // prefix filter (wzorzec getProducts 2022, krok 4)
        String prefix = "Bu";
        List<Product> matching = products.stream()
            .filter(p -> p.name().startsWith(prefix))
            .collect(Collectors.toList());

        // sum / average
        double avg = products.stream()
            .mapToDouble(Product::price)
            .average()
            .orElse(0.0);

        double sum = products.stream()
            .mapToDouble(Product::price)
            .sum();

        // sort
        List<Product> sorted = products.stream()
            .sorted(Comparator.comparing(Product::name))
            .collect(Collectors.toList());
    }

    // -------------------------------------------------------
    // 3. Wzorzec getProducts z prefiksem (2022, krok 4)
    // -------------------------------------------------------
    static Product getByPrefix(List<Product> products, String prefix)
            throws Exception {
        List<Product> matching = products.stream()
            .filter(p -> p.name().startsWith(prefix))
            .collect(Collectors.toList());

        if (matching.isEmpty()) {
            throw new IndexOutOfBoundsException("Nie znaleziono: " + prefix);
        } else if (matching.size() > 1) {
            List<String> names = matching.stream().map(Product::name).collect(Collectors.toList());
            throw new Exception("Niejednoznaczne: " + names); // zastąp AmbiguousException
        }
        return matching.get(0);
    }

    // -------------------------------------------------------
    // 4. Optional - bezpieczne pobieranie
    // -------------------------------------------------------
    static Optional<Product> findFirst(List<Product> products, String name) {
        return products.stream()
            .filter(p -> p.name().equals(name))
            .findFirst();
    }

    // -------------------------------------------------------
    // 5. Collectors.groupingBy
    // -------------------------------------------------------
    static Map<String, List<Product>> groupByFirstLetter(List<Product> products) {
        return products.stream()
            .collect(Collectors.groupingBy(p -> String.valueOf(p.name().charAt(0))));
    }
}
