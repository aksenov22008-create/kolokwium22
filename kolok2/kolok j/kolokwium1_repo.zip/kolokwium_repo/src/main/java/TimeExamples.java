// ============================================================
// SNIPPETY: Czas, strefy, zegar (2024)
// ============================================================

import java.time.*;
import java.time.format.DateTimeFormatter;

public class TimeExamples {

    // -------------------------------------------------------
    // 1. Pobierz bieżący czas systemowy
    //    Wzorzec: setCurrentTime (2024, krok 1)
    // -------------------------------------------------------
    static LocalTime currentTime() {
        return LocalTime.now();
    }

    // -------------------------------------------------------
    // 2. Walidacja godzina/minuta/sekunda (24h)
    //    Wzorzec: setTime (2024, krok 1)
    // -------------------------------------------------------
    static LocalTime validateAndCreate(int hour, int minute, int second) {
        if (hour < 0 || hour > 23)
            throw new IllegalArgumentException("Godzina poza zakresem [0-23]: " + hour);
        if (minute < 0 || minute > 59)
            throw new IllegalArgumentException("Minuta poza zakresem [0-59]: " + minute);
        if (second < 0 || second > 59)
            throw new IllegalArgumentException("Sekunda poza zakresem [0-59]: " + second);
        return LocalTime.of(hour, minute, second);
    }

    // -------------------------------------------------------
    // 3. toString 24h: "hh:mm:ss"
    // -------------------------------------------------------
    static String format24h(LocalTime t) {
        return t.format(DateTimeFormatter.ofPattern("HH:mm:ss"));
    }

    // -------------------------------------------------------
    // 4. toString 12h z AM/PM (2024, krok 2)
    //    Wymagania:
    //      00:00:00 → "12:00:00 AM"
    //      00:01:00 → "12:01:00 AM"
    //      01:00:00 → "1:00:00 AM"
    //      12:00:00 → "12:00:00 PM"
    //      13:00:00 → "1:00:00 PM"
    //      23:59:00 → "11:59:00 PM"
    // -------------------------------------------------------
    static String format12h(LocalTime t) {
        int hour = t.getHour();
        int minute = t.getMinute();
        int second = t.getSecond();

        String ampm = hour < 12 ? "AM" : "PM";
        int h12 = hour % 12;
        if (h12 == 0) h12 = 12;

        return String.format("%d:%02d:%02d %s", h12, minute, second, ampm);
    }

    // -------------------------------------------------------
    // 5. Zmiana strefy (setCity): dodaj/odejmij godziny
    //    Wzorzec: setCity zmieniający godzinę (2024, krok 4)
    // -------------------------------------------------------
    static LocalTime changeTimezone(LocalTime current, int fromOffset, int toOffset) {
        int diffHours = toOffset - fromOffset;
        return current.plusHours(diffHours);
    }

    // -------------------------------------------------------
    // 6. Local Mean Time (czas miejscowy z długości geograficznej)
    //    Wzorzec: City.localMeanTime (2024, krok 5)
    //    longitude: -180..+180 → przesunięcie -12h..+12h
    //    offset = longitude / 180 * 12 godzin = longitude * 4 minuty
    // -------------------------------------------------------
    static LocalTime localMeanTime(LocalTime zoneTime, int timezoneOffset, double longitude) {
        // Czas UTC z danej strefy
        LocalTime utc = zoneTime.minusHours(timezoneOffset);
        // Przesunięcie na podstawie długości geograficznej (w sekundach)
        long offsetSeconds = Math.round(longitude / 180.0 * 12 * 3600);
        return utc.plusSeconds(offsetSeconds);
    }

    // -------------------------------------------------------
    // 7. Różnica między czasem miejscowym a strefowym (w sekundach)
    //    Wzorzec: worstTimezoneFit komparator (2024, krok 6)
    // -------------------------------------------------------
    static long diffSeconds(LocalTime a, LocalTime b) {
        return Math.abs(Duration.between(a, b).toSeconds());
    }

    // -------------------------------------------------------
    // 8. LocalDate - operacje (2021)
    // -------------------------------------------------------
    static void localDateExamples() {
        LocalDate today = LocalDate.now();
        LocalDate start = LocalDate.of(2021, 1, 1);
        LocalDate end = LocalDate.of(2021, 12, 31);

        // Iteracja po datach
        start.datesUntil(end.plusDays(1)).forEach(date -> {
            // przetwórz datę
        });

        // Suma w zakresie (wzorzec sortByDeaths)
        boolean inRange = !today.isBefore(start) && !today.isAfter(end);

        // Format
        String s = today.format(DateTimeFormatter.ofPattern("d.MM.yy"));
    }
}
