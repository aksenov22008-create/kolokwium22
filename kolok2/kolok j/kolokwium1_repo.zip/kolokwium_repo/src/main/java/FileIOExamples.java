// ============================================================
// SNIPPETY: Operacje na plikach i ścieżkach
// Wzorzec obecny w KAŻDYM kolokwium
// ============================================================

import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class FileIOExamples {

    // -------------------------------------------------------
    // 1. Sprawdź czy plik istnieje i można go odczytać
    //    Wzorzec: setFiles (2021, krok 2)
    // -------------------------------------------------------
    static Path validateFile(String pathStr) throws FileNotFoundException {
        Path path = Path.of(pathStr);
        if (!Files.exists(path) || !Files.isReadable(path)) {
            throw new FileNotFoundException(pathStr);
        }
        return path;
    }

    // -------------------------------------------------------
    // 2. Zapis do pliku z tabulatorami
    //    Wzorzec: saveToDataFile (2021, krok 9)
    //    Format: data \t wartość1 \t wartość2
    // -------------------------------------------------------
    static void writeTabSeparated(Path outputPath, List<String[]> rows) throws IOException {
        try (PrintWriter writer = new PrintWriter(Files.newBufferedWriter(outputPath))) {
            for (String[] row : rows) {
                writer.println(String.join("\t", row));
            }
        }
    }

    // Wzorzec z LocalDate:
    static void writeDateRow(PrintWriter writer, LocalDate date, int cases, int deaths) {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("d.MM.yy");
        writer.printf("%s\t%d\t%d%n", date.format(fmt), cases, deaths);
    }

    // -------------------------------------------------------
    // 3. Wczytaj wszystkie linie naraz
    // -------------------------------------------------------
    static List<String> readAllLines(Path path) throws IOException {
        return Files.readAllLines(path);
    }

    // -------------------------------------------------------
    // 4. Stwórz katalog + pliki SVG
    //    Wzorzec: generateAnalogClocksSvg (2024, krok 12)
    // -------------------------------------------------------
    static void createDirAndFiles(String dirName, List<String> cityNames, String svgContent) throws IOException {
        Path dir = Path.of(dirName);
        Files.createDirectories(dir);
        for (String city : cityNames) {
            Path file = dir.resolve(city + ".svg");
            Files.writeString(file, svgContent);
        }
    }

    // -------------------------------------------------------
    // 5. Listowanie plików w katalogu (Files.list)
    //    Wzorzec: addProducts z katalogu (2022, krok 3)
    // -------------------------------------------------------
    static void listCsvFiles(Path dir) throws IOException {
        try (var stream = Files.list(dir)) {
            stream.filter(p -> p.toString().endsWith(".csv"))
                  .forEach(p -> {
                      System.out.println(p.getFileName());
                  });
        }
    }

    // -------------------------------------------------------
    // 6. Zapis stringa do pliku (SVG / tekst)
    // -------------------------------------------------------
    static void writeString(Path path, String content) throws IOException {
        Files.writeString(path, content);
    }

    // -------------------------------------------------------
    // 7. Path z argumentu jako String
    // -------------------------------------------------------
    static Path toPath(String s) {
        return Path.of(s);
    }
}
