// src/main/java/Main.java

public class Main {
    public static void main(String[] args) {
        // === PUNKT WEJŚCIA ===
        // Tu testuj kolejne kroki kolokwium
    }
}
