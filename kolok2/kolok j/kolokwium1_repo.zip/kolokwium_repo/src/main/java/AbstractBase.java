// ============================================================
// SZABLON: Klasa abstrakcyjna z fabryką fromCsv / fromLine
// Wzorzec obecny w KAŻDYM kolokwium (2021-2024)
// ============================================================

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public abstract class AbstractBase {

    // --- Wspólne pole (przenieś do klasy nadrzędnej) ---
    private final String name;

    protected AbstractBase(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    // --- Statyczna fabryka (wzorzec fromCsv / fromLine) ---
    // Wzorzec: otwierasz plik, czytasz linie, budujesz obiekt
    public static AbstractBase fromCsv(Path path) throws IOException {
        try (Scanner scanner = new Scanner(path)) {
            String firstLine = scanner.nextLine();
            // ... logika parsowania
            return null; // zamień na new KlasaKonkretna(...)
        }
    }

    // --- Fabryka wczytująca cały katalog plików ---
    // Wzorzec: wczytaj wszystkie .csv z katalogu
    public static List<AbstractBase> fromDirectory(Path dir) throws IOException {
        var result = new ArrayList<AbstractBase>();
        try (var stream = Files.list(dir)) {
            stream.filter(p -> p.toString().endsWith(".csv"))
                  .forEach(p -> {
                      try {
                          result.add(fromCsv(p));
                      } catch (IOException e) {
                          throw new RuntimeException(e);
                      }
                  });
        }
        return result;
    }

    // --- Abstrakcyjna metoda do nadpisania w podklasach ---
    public abstract double getValue(int year, int month);

    // --- toString do debugowania ---
    @Override
    public String toString() {
        return getClass().getSimpleName() + "[" + name + "]";
    }
}
