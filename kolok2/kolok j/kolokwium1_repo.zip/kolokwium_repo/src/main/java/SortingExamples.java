// ============================================================
// SNIPPETY: Sortowanie i komparatory
// Wzorzec obecny w KAŻDYM kolokwium
// ============================================================

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class SortingExamples {

    // -------------------------------------------------------
    // 1. Sortowanie listy malejąco po liczbie (Comparator)
    //    Wzorzec: sortByDeaths (2021)
    // -------------------------------------------------------
    record Country(String name, int deaths) {}

    static void sortByDeathsDesc(List<Country> list) {
        list.sort(Comparator.comparingInt(Country::deaths).reversed());
    }

    // -------------------------------------------------------
    // 2. Sortowanie za pomocą Comparator.comparing + reversed
    // -------------------------------------------------------
    static void sortByNameAsc(List<Country> list) {
        list.sort(Comparator.comparing(Country::name));
    }

    // -------------------------------------------------------
    // 3. Sortowanie z kluczem obliczanym (np. suma z zakresu dat)
    //    Wzorzec: sortByDeaths między datami (2021, krok 8)
    // -------------------------------------------------------
    static void sortByRange(List<Country> list, LocalDate from, LocalDate to) {
        list.sort(Comparator.comparingInt((Country c) -> {
            // Tu oblicz sumę dla c z zakresu [from, to]
            return c.deaths(); // zastąp prawdziwą logiką
        }).reversed());
    }

    // -------------------------------------------------------
    // 4. Sortowanie przez Stream + collect
    // -------------------------------------------------------
    static List<Country> sortedCopy(List<Country> list) {
        return list.stream()
                   .sorted(Comparator.comparing(Country::name))
                   .collect(Collectors.toList());
    }

    // -------------------------------------------------------
    // 5. Metoda statyczna jako komparator (kolokwium 2024, krok 6)
    //    public static int worstTimezoneFit(City a, City b) { ... }
    //    Użycie: list.sort(City::worstTimezoneFit)
    // -------------------------------------------------------
    static int compareByAbsDiff(Country a, Country b) {
        // Math.abs(różnica) - większa różnica = wcześniej
        return Integer.compare(Math.abs(b.deaths()), Math.abs(a.deaths()));
    }

    // Użycie: list.sort(SortingExamples::compareByAbsDiff)

    // -------------------------------------------------------
    // 6. TreeMap / sortowanie mapy po kluczu
    // -------------------------------------------------------
    static <V> Map<String, V> sortedMap(Map<String, V> map) {
        return new TreeMap<>(map);
    }
}
