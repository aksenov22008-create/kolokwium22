// ============================================================
// SNIPPETY: Parsowanie CSV
// Używane we WSZYSTKICH kolokwiach
// ============================================================

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class CsvParser {

    // -------------------------------------------------------
    // 1. Wczytaj wszystkie linie naraz
    // -------------------------------------------------------
    public static List<String> readLines(Path path) throws IOException {
        return Files.readAllLines(path);
    }

    // -------------------------------------------------------
    // 2. Podziel linię na kolumny (separator: ; lub ,)
    // -------------------------------------------------------
    public static String[] splitSemicolon(String line) {
        return line.split(";", -1);   // -1 żeby nie pomijać pustych końcowych
    }

    public static String[] splitComma(String line) {
        return line.split(",", -1);
    }

    // -------------------------------------------------------
    // 3. Konwersja polskich liczb (przecinek → kropka)
    // -------------------------------------------------------
    public static double parsePolishDouble(String s) {
        return Double.parseDouble(s.trim().replace(",", "."));
    }

    // -------------------------------------------------------
    // 4. Parsowanie dat
    // -------------------------------------------------------
    // Format "M/d/yy"  → np. "1/5/21" (kolokwium 2021)
    public static LocalDate parseUsDate(String s) {
        return LocalDate.parse(s.trim(), DateTimeFormatter.ofPattern("M/d/yy"));
    }

    // Format "d.MM.yy" → np. "05.01.21" (zapis do pliku 2021)
    public static LocalDate parsePlDate(String s) {
        return LocalDate.parse(s.trim(), DateTimeFormatter.ofPattern("d.MM.yy"));
    }

    // -------------------------------------------------------
    // 5. Wczytaj CSV do mapy nagłówek → lista wartości (kolumny)
    //    Wzorzec: kolokwium 2021 - confirmed_cases.csv
    // -------------------------------------------------------
    public static Map<String, List<String>> readByColumns(Path path, String separator) throws IOException {
        List<String> lines = Files.readAllLines(path);
        if (lines.isEmpty()) return Collections.emptyMap();

        String[] headers = lines.get(0).split(separator, -1);
        Map<String, List<String>> result = new LinkedHashMap<>();
        for (String h : headers) result.put(h, new ArrayList<>());

        for (int i = 1; i < lines.size(); i++) {
            String[] cols = lines.get(i).split(separator, -1);
            for (int j = 0; j < headers.length && j < cols.length; j++) {
                result.get(headers[j]).add(cols[j].trim());
            }
        }
        return result;
    }

    // -------------------------------------------------------
    // 6. Wczytaj CSV transponowane (wiersze = klucze)
    //    Wzorzec: kolokwium 2022 - NonFoodProduct (ceny w kolumnach)
    // -------------------------------------------------------
    public static Double[] readDoubleRow(Path path, String separator, int rowIndex) throws IOException {
        List<String> lines = Files.readAllLines(path);
        String[] parts = lines.get(rowIndex).split(separator, -1);
        return Arrays.stream(parts)
                     .map(s -> parsePolishDouble(s))
                     .toArray(Double[]::new);
    }

    // -------------------------------------------------------
    // 7. Wczytaj CSV do mapy klucz (pierwsza kolumna) → wartości
    //    Wzorzec: kolokwium 2022 - FoodProduct (województwa jako klucze)
    // -------------------------------------------------------
    public static Map<String, Double[]> readByRows(Path path, String separator, int skipLines) throws IOException {
        List<String> lines = Files.readAllLines(path);
        Map<String, Double[]> result = new LinkedHashMap<>();
        for (int i = skipLines; i < lines.size(); i++) {
            String[] cols = lines.get(i).split(separator, -1);
            String key = cols[0].trim();
            Double[] values = new Double[cols.length - 1];
            for (int j = 1; j < cols.length; j++) {
                values[j - 1] = parsePolishDouble(cols[j]);
            }
            result.put(key, values);
        }
        return result;
    }

    // -------------------------------------------------------
    // 8. Scanner - wczytywanie linia po linii (oszczędność pamięci)
    // -------------------------------------------------------
    public static void scanLines(Path path) throws IOException {
        try (Scanner sc = new Scanner(path)) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                // ... przetwórz
            }
        }
    }

    // -------------------------------------------------------
    // 9. Przeliczenie roku + miesiąca → indeks tablicy (od 2010-01)
    //    Wzorzec: kolokwium 2022
    // -------------------------------------------------------
    public static int toIndex(int year, int month) {
        // Sprawdzenie zakresu 01.2010 - 03.2022
        if (year < 2010 || year > 2022) throw new IndexOutOfBoundsException("Rok poza zakresem: " + year);
        if (month < 1 || month > 12) throw new IndexOutOfBoundsException("Miesiąc poza zakresem: " + month);
        int idx = (year - 2010) * 12 + (month - 1);
        if (idx > (2022 - 2010) * 12 + 2) throw new IndexOutOfBoundsException("Data poza zakresem");
        return idx;
    }
}
