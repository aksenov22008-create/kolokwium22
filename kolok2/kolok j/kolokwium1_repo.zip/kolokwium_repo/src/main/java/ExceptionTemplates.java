// ============================================================
// SZABLON: Wyjątki własne
// Wzorzec obecny w KAŻDYM kolokwium
// ============================================================


// -------------------------------------------------------
// 1. Checked exception (extends Exception)
//    → kompilator wymusza przechwycenie (throws / try-catch)
//    Wzorzec: CountryNotFoundException (2021), AmbigiousProductException (2022)
// -------------------------------------------------------
class NotFoundException extends Exception {
    private final String missingName;

    public NotFoundException(String missingName) {
        super(missingName);   // getMessage() zwróci missingName
        this.missingName = missingName;
    }

    public String getMissingName() {
        return missingName;
    }
}


// -------------------------------------------------------
// 2. Unchecked exception (extends RuntimeException)
//    → nie trzeba deklarować throws
//    Wzorzec: RuntimeException z getMessage() = nazwa miasta (2023)
// -------------------------------------------------------
class DomainException extends RuntimeException {
    public DomainException(String message) {
        super(message);
    }
}


// -------------------------------------------------------
// 3. Wyjątek z listą nazw (do komunikatu)
//    Wzorzec: AmbigiousProductException (2022)
// -------------------------------------------------------
class AmbiguousException extends Exception {
    private final java.util.List<String> candidates;

    public AmbiguousException(java.util.List<String> candidates) {
        super("Niejednoznaczne: " + candidates);
        this.candidates = candidates;
    }

    public java.util.List<String> getCandidates() {
        return candidates;
    }
}


// -------------------------------------------------------
// 4. Jak rzucić i przechwycić
// -------------------------------------------------------
class ExceptionExamples {
    static void throwChecked(String name) throws NotFoundException {
        throw new NotFoundException(name);
    }

    static void catchAndPrint() {
        try {
            throwChecked("Polska");
        } catch (NotFoundException e) {
            System.out.println(e.getMessage()); // "Polska"
        }
    }

    // Wzorzec "pomiń nieznane, zbierz resztę" (kolokwium 2021, krok 6)
    static java.util.List<String> collectSkippingMissing(String[] names) {
        var result = new java.util.ArrayList<String>();
        for (String name : names) {
            try {
                throwChecked(name);
                result.add(name);
            } catch (NotFoundException e) {
                System.out.println(e.getMessage()); // wypisz i pomiń
            }
        }
        return result;
    }
}
