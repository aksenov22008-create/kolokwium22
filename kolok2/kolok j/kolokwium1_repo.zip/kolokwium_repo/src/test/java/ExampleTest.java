// ============================================================
// SZABLON: Testy JUnit 5
// Wzorzec: kolokwium 2023 (kroki 4, 8, 12) i 2024
// ============================================================

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.*;
import org.junit.jupiter.params.provider.*;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

class ExampleTest {

    // -------------------------------------------------------
    // 1. Prosty test assertEquals / assertTrue / assertFalse
    //    Wzorzec: test inside() (2023, krok 4)
    // -------------------------------------------------------
    @Test
    void pointInsidePolygon() {
        // Stwórz wielokąt - np. prostokąt (0,0)-(10,0)-(10,10)-(0,10)
        // Polygon polygon = new Polygon(List.of(new Point(0,0), new Point(10,0), ...));
        // Point inside = new Point(5, 5);
        // assertTrue(polygon.inside(inside));
        assertTrue(true); // zastąp prawdziwym testem
    }

    @Test
    void pointBelowPolygon() {
        assertFalse(false); // zastąp
    }

    @Test
    void pointRightOfPolygon() {
        assertFalse(false); // zastąp
    }

    // -------------------------------------------------------
    // 2. Test wyjątku (assertThrows)
    //    Wzorzec: addCity poza lądem (2023, krok 8)
    // -------------------------------------------------------
    @Test
    void addCityNotOnLandThrows() {
        // RuntimeException ex = assertThrows(RuntimeException.class, () -> {
        //     land.addCity(cityOnWater);
        // });
        // assertEquals("NazwaMiasta", ex.getMessage());
    }

    // -------------------------------------------------------
    // 3. Test parametryzowany (MethodSource)
    //    Wzorzec: CityTest z addResourcesInRange (2023, krok 12)
    // -------------------------------------------------------
    @ParameterizedTest
    @MethodSource("resourceCases")
    void addResourceTest(String cityType, String resourceType, boolean expected) {
        // City city = cityType.equals("port") ? portCity : inlandCity;
        // Resource resource = new Resource(new Point(0,0), Resource.Type.valueOf(resourceType));
        // city.addResourcesInRange(List.of(resource), 1000);
        // assertEquals(expected, city.resources.contains(Resource.Type.valueOf(resourceType)));
        assertEquals(expected, expected); // zastąp
    }

    static Stream<Arguments> resourceCases() {
        return Stream.of(
            Arguments.of("inland", "Coal", true),      // węgiel - miasto śródlądowe - ok
            Arguments.of("inland", "Wood", false),     // drewno - poza zasięgiem - nie
            Arguments.of("port",   "Fish", true),      // ryby - miasto portowe - ok
            Arguments.of("inland", "Fish", false)      // ryby - miasto nieportowe - nie
        );
    }

    // -------------------------------------------------------
    // 4. Test parametryzowany (CsvSource) - prostszy
    // -------------------------------------------------------
    @ParameterizedTest
    @CsvSource({
        "0, 0, 0, 12:00:00 AM",
        "12, 0, 0, 12:00:00 PM",
        "13, 0, 0, 1:00:00 PM",
        "23, 59, 0, 11:59:00 PM"
    })
    void clockFormat12h(int hour, int minute, int second, String expected) {
        // DigitalClock clock = new DigitalClock(DigitalClock.Mode.TWELVE_HOUR, someCity);
        // clock.setTime(hour, minute, second);
        // assertEquals(expected, clock.toString());
    }

    // -------------------------------------------------------
    // 5. @BeforeEach / @AfterEach
    // -------------------------------------------------------
    // @BeforeEach
    // void setUp() { /* inicjalizacja */ }

    // @AfterEach
    // void tearDown() { /* sprzątanie */ }

    // -------------------------------------------------------
    // 6. assertAll - sprawdź wiele warunków naraz
    // -------------------------------------------------------
    @Test
    void multipleAssertions() {
        assertAll(
            () -> assertEquals(1, 1),
            () -> assertTrue(true),
            () -> assertNotNull("notNull")
        );
    }
}
